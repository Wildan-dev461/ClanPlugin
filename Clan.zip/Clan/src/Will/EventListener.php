<?php

namespace Will;

use Ifera\ScoreHud\event\TagsResolveEvent;
use _64FF00\PureChat\PureChat;
use _64FF00\PureChat\PCListener;
use JsonException;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByChildEntityEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\Listener;
use pocketmine\player\chat\LegacyRawChatFormatter;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\LevelSoundEventPacket;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class EventListener implements Listener
{

public function onChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        $message = $event->getMessage();
        if($event->isCancelled()) return;

        if(Clan::getInstance()->pureChat !== null){
            $worldName = Clan::getInstance()->pureChat->getConfig()->get("enable-multiworld-chat") ? $player->getWorld()->getFolderName() : null;
            $chatFormat = Clan::getInstance()->pureChat->getChatFormat($player, $message, $worldName);
            $chatFormat = str_replace("{clan}", ($this->getPlayerClan($player) == "[N\A]" ? "[N\A]" : $this->getPlayerClan($player)), $chatFormat);
            $event->setFormatter(new LegacyRawChatFormatter($chatFormat));
        }
    }
 }